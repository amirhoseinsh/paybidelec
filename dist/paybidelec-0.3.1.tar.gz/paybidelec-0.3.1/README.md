# Pay as a bid Package for Electricity Market

This is a package about simulation pay as a bid electricity auction.
